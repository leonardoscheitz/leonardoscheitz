#!/usr/bin/env python3
"""Self-hosted monochrome GitHub profile visual cards.

Usage:
  GITHUB_TOKEN=<actions token> python scripts/update_profile_stats.py
  python scripts/update_profile_stats.py --bootstrap

Production mode queries public GitHub GraphQL data using only stdlib. It
never fabricates contribution data or replaces visuals on an API failure.
"""
import argparse
from collections import Counter
from datetime import date
from html import escape
import json
import os
from pathlib import Path
import urllib.error
import urllib.request

USER = "leonardoscheitz"
OUT = Path(__file__).resolve().parents[1] / "assets"
BG = "#0C0D0F"
LINE = "#292B31"
WHITE = "#F4F4F4"
MUTED = "#92939B"
SECONDARY = "#55565E"

QUERY = '''
query($login: String!) {
  user(login: $login) {
    login
    repositories(first: 100, isFork: false, privacy: PUBLIC, ownerAffiliations: OWNER) {
      totalCount
      nodes {
        stargazerCount
        primaryLanguage { name }
      }
    }
    contributionsCollection {
      contributionCalendar {
        totalContributions
        weeks {
          contributionDays { date contributionCount }
        }
      }
    }
  }
}
'''


def github_data(token: str):
    request = urllib.request.Request(
        "https://api.github.com/graphql",
        data=json.dumps({"query": QUERY, "variables": {"login": USER}}).encode("utf-8"),
        headers={
            "Authorization": "Bearer " + token,
            "Accept": "application/vnd.github+json",
            "Content-Type": "application/json",
            "User-Agent": "leo-profile-metrics/1.0",
        },
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        payload = json.load(response)
    if payload.get("errors"):
        raise RuntimeError("GitHub GraphQL reported errors: " + repr(payload["errors"]))
    user = (payload.get("data") or {}).get("user")
    if not user:
        raise RuntimeError("GitHub did not return the requested user")
    return user


def root_svg(w, h, inner, desc):
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" '
        f'viewBox="0 0 {w} {h}" role="img" aria-label="{escape(desc, quote=True)}">'
        f'<title>{escape(desc)}</title>'
        f'<rect x="0.5" y="0.5" width="{w-1}" height="{h-1}" rx="12" fill="{BG}" stroke="{LINE}"/>'
        '<style>text{font-family:Arial,Helvetica,sans-serif;} .mono{font-family:Menlo,Consolas,monospace}</style>'
        + inner + '</svg>\n'
    )


def text(x, y, value, size=16, color=WHITE, weight=400, spacing=None, cls=""):
    letter = f' letter-spacing="{spacing}"' if spacing is not None else ''
    return (f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" '
            f'font-weight="{weight}"{letter} class="{cls}">{escape(str(value))}</text>')


def heading(label, w):
    return (text(30, 36, 'LS / '+label, 15, WHITE, 700, '1', 'mono')
            + f'<line x1="30" y1="53" x2="{w-30}" y2="53" stroke="{LINE}"/>')


def stats_svg(nodes):
    w,h = 570,230
    langs = Counter((r.get('primaryLanguage') or {}).get('name') for r in nodes)
    langs.pop(None, None)
    vals = [(len(nodes), 'PUBLIC REPOS'),
            (sum(int(r.get('stargazerCount', 0)) for r in nodes), 'TOTAL STARS'),
            (len(langs), 'LANGUAGES')]
    svg = heading('REPOSITORY METRICS',w)
    for i,(value,label) in enumerate(vals):
        x=32+i*187
        svg+=text(x,129,value,48,WHITE,700)
        svg+=text(x,162,label,11,MUTED,700,'1.1','mono')
        if i!=2:
            svg+=f'<line x1="{x+155}" y1="81" x2="{x+155}" y2="181" stroke="{LINE}"/>'
    svg+=text(30,207, 'PUBLIC REPOSITORIES · GITHUB API',11,SECONDARY,500,0.8,'mono')
    return root_svg(w,h,svg,'GitHub public repository metrics for '+USER)


def languages_svg(nodes):
    w,h=570,230
    langs=Counter((r.get('primaryLanguage') or {}).get('name') for r in nodes)
    langs.pop(None,None)
    svg=heading('TOP LANGUAGES',w)
    if not langs:
        svg+=text(30,123,'No primary languages reported',17,MUTED)
    else:
        for i,(name,count) in enumerate(langs.most_common(3)):
            y=91+i*45
            svg+=text(30,y,name,16,WHITE,600)
            svg+=text(510,y,str(count)+' repo'+('s' if count!=1 else ''),11,MUTED,500,cls='mono')
            svg+=f'<rect x="30" y="{y+8}" width="490" height="8" rx="4" fill="{LINE}"/>'
            fraction=count/max(langs.values())
            svg+=f'<rect x="30" y="{y+8}" width="{max(7,490*fraction):.1f}" height="8" rx="4" fill="{WHITE if i==0 else ["#AAAAAA","#707070"][min(i-1,1)]}"/>'
    svg+=text(30,207,'PRIMARY LANGUAGE PER PUBLIC REPOSITORY',11,SECONDARY,500,0.8,'mono')
    return root_svg(w,h,svg,'Most common primary languages in '+USER+' public repositories')


def contributions_svg(calendar):
    w,h=1190,255
    svg=heading('CONTRIBUTION CALENDAR',w)
    weeks=calendar.get('weeks') if calendar else None
    if not weeks:
        svg+='<rect x="30" y="82" width="1130" height="106" rx="8" fill="#141518" stroke="#3A3A3A" stroke-dasharray="5 5"/>'
        svg+=text(62,127,'CALENDAR SYNC PENDING',20,WHITE,700,1.1,'mono')
        svg+=text(62,154,'Run the included GitHub Action once to populate verified activity.',15,MUTED)
        svg+=text(30,228,'GRAPHICS ARE HOSTED IN THIS REPOSITORY',11,SECONDARY,500,1,'mono')
        return root_svg(w,h,svg,'GitHub contributions: first synchronization pending')
    # GitHub returns the calendar in weekly chunks; no synthetic counts are used.
    total=int(calendar['totalContributions'])
    svg+=text(30,85,'LAST 12 MONTHS',13,MUTED,600,1,'mono')
    svg+=text(900,85,str(total)+' CONTRIBUTIONS',13,WHITE,700,0.7,'mono')
    cell=12; gap=4; start_x=85; start_y=111
    months=['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC']
    last_month=None
    for i,week in enumerate(weeks):
        days=week.get('contributionDays') or []
        if days:
            try:
                month=int(days[0]['date'][5:7])
                if month!=last_month:
                    svg+=text(start_x+i*(cell+gap),102,months[month-1],10,MUTED,500,cls='mono')
                    last_month=month
            except (KeyError, ValueError): pass
        for j,day in enumerate(days):
            count=int(day['contributionCount'])
            fill=('#1C1D20' if count==0 else '#55565B' if count==1 else '#8E8F93' if count<=3 else '#D5D5D5' if count<=6 else '#FFFFFF')
            d=escape(day['date'])
            svg+=(f'<rect x="{start_x+i*(cell+gap)}" y="{start_y+j*(cell+gap)}" '
                  f'width="{cell}" height="{cell}" rx="2" fill="{fill}">'
                  f'<title>{d}: {count} contribution(s)</title></rect>')
    svg+=text(30,236,'SOURCE: GITHUB CONTRIBUTION CALENDAR · PUBLIC ACTIVITY',11,SECONDARY,500,1,'mono')
    return root_svg(w,h,svg,'GitHub public contribution activity for '+USER)


def write_assets(nodes,calendar):
    OUT.mkdir(parents=True,exist_ok=True)
    for name, content in {
        'github-stats.svg':stats_svg(nodes),
        'github-languages.svg':languages_svg(nodes),
        'github-activity.svg':contributions_svg(calendar),
    }.items():
        (OUT/name).write_text(content,encoding='utf-8')
        print('wrote',OUT/name)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bootstrap',action='store_true',help='Render verified snapshot of public repos without contributions (for initial installation)')
    args=parser.parse_args()
    if args.bootstrap:
        # These values were checked on 2026-10-30 against the connected GitHub repository list.
        # Never estimate or fabricate the public contribution calendar.
        nodes=[{'stargazerCount':0,'primaryLanguage':None},
               {'stargazerCount':0,'primaryLanguage':{'name':'Java'}},
               {'stargazerCount':0,'primaryLanguage':{'name':'HTML'}}]
        write_assets(nodes,None)
        return
    token=os.getenv('GITHUB_TOKEN')
    if not token:raise SystemExit('GITHUB_TOKEN is required. Use --bootstrap only for initial installation.')
    data=github_data(token)
    repos=data['repositories']
    cal=data['contributionsCollection']['contributionCalendar']
    nodes=repos['nodes']
    if nodes is None or cal is None:
        raise RuntimeError('Missing required GitHub metrics; keeping existing assets unchanged')
    write_assets(nodes,cal)

if __name__=='__main__': main()
