# Leonardo Scheitz · GitHub Profile / Reliable Stats

## Instalação

1. Abra **github.com/leonardoscheitz/leonardoscheitz** no branch `main`.
2. Substitua o `readme.md` pelo arquivo deste pacote. Preserve a pasta `assets/`, incluindo `banner.png` e os 3 SVGs.
3. Envie também `scripts/update_profile_stats.py` e `.github/workflows/update-profile-stats.yml`, mantendo os caminhos.
4. Em **Actions → Update profile graphics → Run workflow**, execute uma vez. Isso trocará o calendário de sincronização inicial pelos dados verdadeiros de contribuições.
5. Depois disso, o workflow tenta atualizar automaticamente todos os dias às 05:23 UTC.

## Por que funciona?

Os SVGs são arquivos **do próprio repositório**, sem links externos que possam quebrar. A ação usa a API GraphQL oficial do GitHub, apenas dados de repositórios públicos, e o `GITHUB_TOKEN` automático. Se a API falhar, o script encerra com erro sem sobrescrever os gráficos existentes.

## Observações

- A versão incluída dos 2 primeiros cards é uma fotografia verificada da conta em 30/10/2026.
- O calendário de contribuições só mostra dados reais depois da primeira execução do workflow.
- Actions pode precisar estar habilitado e a política da conta precisa permitir a gravação por `GITHUB_TOKEN` (`contents: write`).
- O GitHub pode suspender workflows agendados após 60 dias sem atividade no repositório. É possível executá-los manualmente.
- Se o banner já estiver na pasta `assets` do repositório, não é necessário enviá-lo novamente.
